Configuration InstallWindowsFeatures {

    Import-DscResource -ModuleName PsDesiredStateConfiguration

    Node "localhost" {

        LocalConfigurationManager {
            RebootNodeIfNeeded = $true
            ActionAfterReboot  = 'ContinueConfiguration'
        }

        WindowsFeature Hyper-V {
            Name   = "Hyper-V"
            Ensure = "Present"
            IncludeAllSubFeature = $true
        }

        WindowsFeature Hyper-V-PowerShell {
            Name   = "Hyper-V-PowerShell"
            Ensure = "Present"
            IncludeAllSubFeature = $true
        }
        Script InstallVirtualMachinePlatform {
            GetScript = { return @{ Result = "Get" } }
            TestScript = { return $false }
            SetScript = {
                Enable-WindowsOptionalFeature -Online -FeatureName VirtualMachinePlatform -All
            }
        }
    }
    
}